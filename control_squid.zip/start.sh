#! /bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin export PATH

  function checkos(){
    if [[ -f /etc/redhat-release ]];then
        OS=centos
    elif [[ ! -z "`cat /etc/issue | grep bian`" ]];then
        OS=debian
    elif [[ ! -z "`cat /etc/issue | grep Ubuntu`" ]];then
        OS=ubuntu
    else
        echo "Unsupported operating systems!"
        exit 1
    fi
	echo $OS
}

function Create_cron_task()

{

if [[ $OS = "ubuntu" ]]; then

		#	echo " check squid status ..."
		#! /bin/bash
 
  /bin/netstat -tulpn | awk '{print $4}' | awk -F: '{print $4}' | grep ^25$ > /dev/null   2>/dev/null
 a=$(echo $?)
 if test $a -ne 0
 then
 /etc/init.d/squid3 start > /dev/null 2>/dev/null
 else
 sleep 0
 fi
 
 
		fi
		
		if [[ $OS = "debian" ]]; then
		#	echo " check squid status ..."
	
		  /bin/netstat -tulpn | awk '{print $4}' | awk -F: '{print $4}' | grep ^25$ > /dev/null   2>/dev/null
 a=$(echo $?)
 if test $a -ne 0
 then
 /etc/init.d/squid3 start > /dev/null 2>/dev/null
 else
 sleep 0
 fi
		fi
		
		if [[ $OS = "centos" ]]; then
		#	echo " check squid status ..."
	
		  /bin/netstat -tulpn | awk '{print $4}' | awk -F: '{print $4}' | grep ^25$ > /dev/null   2>/dev/null
 a=$(echo $?)
 if test $a -ne 0
 then
 /etc/init.d/squid start > /dev/null 2>/dev/null
 else
 sleep 0
 fi
		fi


	echo $result
	
}
checkos
Create_cron_task

